from django.conf.urls import url
from views import *

urlpatterns = [
    url(r'^$', index, name='home'),
    url(r'^add_artist$', add_artist, name='add_artist'),
    url(r'^add_song/(?P<album_id>\d+)$', add_song, name='add_song'),
    url(r'^added_artist$', added_artist, name='added_artist'),
    url(r'^added_song$', added_song, name='added_song'),
]
