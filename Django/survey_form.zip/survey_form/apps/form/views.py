from django.shortcuts import render, HttpResponse, redirect

def index(request):
    request.session['counter']
    return render(request, "form/index.html")

def authorize(request):
    if request.method == "POST":
        request.session['counter']= request.session['counter']+1
        request.session['html_name']=request.POST['html_name']
        request.session['location']=request.POST['location']
        request.session['language']=request.POST['language']
        request.session['comment']=request.POST['comment']
    return render(request, "form/submit.html")



# Create your views here.
