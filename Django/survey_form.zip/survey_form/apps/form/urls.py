from django.conf.urls import url
from views import *

urlpatterns = [
    url(r'^$', index),
    url(r'^authorize$', authorize)
    # url(r'^submit$', submits)

]
