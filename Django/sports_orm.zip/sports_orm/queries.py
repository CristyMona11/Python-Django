import django
from apps.leagues.models import Team, Player, League
from django.db.models import Count
django.setup()

def first():
    leagues = League.objects.filter(sport__in=('Baseball', 'Soccer'))
    for l in leagues:
        print "=", l.name
        teams = l.teams.exclude(location='Dallas').exclude(location='DC')
        for team in teams:
            print "\t>", team.location, team.team_name
            for player in team.curr_players.all():
                print "\t\t-", player.first_name, player.last_name

def second():
    kings = Player.objects.filter(last_name='King')
    for k in kings:
        print k.first_name, k.last_name
        for team in k.all_teams.all():
            print "\t", team.location, team.team_name

def third():
    teams = Team.objects.filter(all_players__last_name='King')
    for team in teams:
        print team.location, team.team_name
        for player in team.all_players.all():
            print "\t", player.first_name, player.last_name
player= Player.objects.filter(first_name="Sophia")
for p in player:
    print p.curr_team.team_name

player= Player.objects.filter(first_name="Sophia")
for p in player:
    print p.curr_team.league.name

player= Player.objects.filter(last_name="Flores").exclude(curr_team__team_name="Washington Roughriders")
for p in player:
    print p.first_name,p.last_name

team= Team.objects.filter(all_players__first_name="Samuel",all_players__last_name="Evans")
for t in team:
    print t.team_name

player=Player.objects.filter(all_teams__team_name="Tiger-Cats")
for p in player:
    print p.first_name, p.last_name

player=Player.objects.exclude(curr_team__team_name="Vikings").filter(all_teams__team_name="Vikings")
for p in player:
    print p.first_name, p.last_name

team= Team.objects.exclude(team_name__contains="Colts").filter(all_players__first_name="Jacob", all_players__last_name="Gray")
for t in team:
    print t.team_name

player= Player.objects.filter(first_name="Joshua", all_teams__league__name__contains="Atlantic Federation of Amateur Baseball Players")
for p in player:
    print p.first_name, p.last_name

teams=Team.objects.annotate(players=Count("all_players")).filter(players__gt=12)
for t in teams:
    print t.team_name

player= Player.objects.all().annotate(teams=Count("all_teams__team_name")).order_by('teams')
for p in player:
    print p.first_name, p.last_name
