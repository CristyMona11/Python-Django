from django.conf.urls import url
from views import *

urlpatterns = [
    url(r'^$', index),
    url(r'^submit$', submit),
    url(r'^remove_course$', remove),
    url(r'^deleted$', deleted),
    url(r'^keep_course$', keep)
]
