from django.shortcuts import render, HttpResponse
from datetime import datetime

def index(request):
    return HttpResponse()

def index(request):
    # context = {
    #
    # }
    return render(request,'timedisplay/index.html', {'datetime': datetime.now()})
# Create your views here.
