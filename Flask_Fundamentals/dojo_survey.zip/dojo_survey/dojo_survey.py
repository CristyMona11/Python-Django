from flask import Flask, render_template,request,redirect
app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/authorize', methods=['POST'])
def auth():
    server_name = request.form['name']
    server_location = request.form['location']
    server_fave_language = request.form['fave_language']
    server_description = request.form['description']
    return render_template('/submit.html', name=server_name, location= server_location, fave_language=server_fave_language, description=server_description )

app.run(debug=True)
