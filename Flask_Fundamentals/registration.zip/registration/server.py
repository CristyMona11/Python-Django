from flask import Flask, render_template,request,flash,redirect,session
import re
app = Flask(__name__)

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
app.secret_key = 'secret7s'


@app.route('/')
def index():
    return render_template("index.html")

@app.route('/authorize', methods=['POST'])
def auth():
    if len(request.form['server_email'])<1:
        flash('Oops!You forgot your email.')
        return redirect('/')
    if not EMAIL_REGEX.match(request.form['server_email']):
        flash("Invalid Email Address!")
        return redirect('/')
    if len(request.form['server_fname'])<1:
        flash('Oops!You forgot your first name.')
        return redirect('/')
    if str.isalpha(str(request.form['server_fname'])) is False:
        flash('Please make sure your first name does not contain any numbers.')
        return redirect('/')
    if len(request.form['server_lname'])<1:
        flash('Oops!You forgot your last name.')
        return redirect('/')
    if str.isalpha(str(request.form['server_lname'])) is False:
        flash('Please make sure your last name does not contain any numbers.')
        return redirect('/')
    if len(request.form['server_password'])<1:
        flash('Oops!You forgot your password.')
        return redirect('/')
    if len(request.form['server_password'])<=8:
        flash('Your password must be more than eight characters.')
        return redirect('/')
    if len(request.form['server_rpassword'])<1:
        flash('Oops!You forgot to confirm your password.')
        return redirect('/')
    if request.form['server_password'] != request.form['rserver_password']:
        flash ('Your passwords do not match!!!')
        return redirect('/')
    else:
        flash('Perfect! You are all set, and good to go!')
        return redirect('/')
app.run(debug=True)
